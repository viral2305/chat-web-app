import React, {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import axios from "axios";


const CreateGroup = () => {
    const navigate = useNavigate();
    const [group,setGroup] = useState({name:"",members:[]});
    const [members,setMembers] = useState(null);
    useEffect(() => {
        if (members === null){
            axios.get("http://localhost:8000/users").then((resp) => {
                setMembers(JSON.parse(JSON.stringify(resp.data)))
            });
        }
    },[]);
    const handleGoBack = () => {
        navigate(-1);
    };
    const handleOnChange  = (event) => {
        let {name,value} = event.target;
        setGroup({...group,[name]:value});
    };
    const handleMembers = (event) => {
        group.members.push(event.target.value);
        setGroup({...group});
    };
    const handleOnSubmit = () => {
        axios.post("http://localhost:8000/createGroup",group).then((resp) => {
           console.log("resp",resp);
        });
    };
  return (
      <div className="w-[400px] h-[600px] bg-[#2d343e] p-[1rem] flex flex-col justify-between">
          <div className="flex">
              <span className="w-[40px]"><i className="far fa-arrow-left cursor-pointer" onClick={handleGoBack}/></span>
              Create Group
          </div>
          <div className="flex flex-col w-full h-[90%] items-center">
              <input
                  type="text"
                  id="name"
                  placeholder="Enter Group Name"
                  name="name"
                  value={group.name}
                  onChange={handleOnChange}
                  className="h-[50px] w-[80%] bg-[#404450] rounded-[5px] border-none pl-[10px]"
              />
              <div className=" flex-col w-[80%] mt-[4px] rounded-[5px] bg-[#404450] h-[70%] ">
                  {members !== null &&
                      members.map((item,index) => (
                          <div className="justify-between" key={index}><span className="ml-[10px] w-[60%]">{item.name} </span><span className=""><input type="checkbox" value={item.name} onChange={handleMembers}/></span></div>
                      ))
                  }
              </div>
              <button
                  className="w-[100px] pt-[0.5rem] pr-[1rem] pb-[0.5rem] pl-[1rem] border-none bg-[#ffac41] rounded-[5px] text-[black] cursor-pointer mt-[30px] ml-[190px]"
                  onClick={handleOnSubmit}>Submit
              </button>
          </div>
      </div>
  );
};

export default CreateGroup;