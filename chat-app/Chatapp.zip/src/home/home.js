import React, {useEffect, useState} from "react";
import "./home.scss";
import { useNavigate} from "react-router-dom";
import axios from "axios";
import Popover from "@material-ui/core/Popover";
import Chat from "../chat/chat";


function Homepage({socket, user}) {
    const navigate = useNavigate();
    const [users, setUsers] = useState(null);
    const [groups, setGroups] = useState([]);
    const [chat,setChat] = useState(false);
    const [msgType,setMsgType] = useState('');
    const [item,setItem] = useState({});
    const [anchorEl, setAnchorEl] = React.useState(null);
    useEffect(() => {
        if (user === undefined || user === "") {
            navigate("/login");
        }
        if (users === null) {
            axios.get("http://192.168.29.246:8000/users").then((res) => {
                setUsers(res.data);
            })
        }
        axios.get(`http://192.168.29.246:8000/groups/${user.name}`).then((res) => {
            setGroups(JSON.parse(JSON.stringify(res.data)));
        })
    }, [user]);
    const handleCreateGroup = () => {
        navigate("/createGroup");
    };
    const handleLogOut = () => {
        localStorage.removeItem("user");
        navigate("/login");
    };
    const handleOptions = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    const handleOnMessage = (item,type) => {
        setChat(true);
        setMsgType(type);
        setItem(item);
    };
    const handleOnChat = () => {
        setChat(false);
    };
    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;
    return (
        <>
             <div className="flex w-[500px] h-[500px] bg-[#2d343e] rounded-[5px] flex-col p-8">
                <div className="ml-[0px]">
                    <i className="far fa-ellipsis-v ml-[40px] cursor-pointer" onClick={handleOptions}/>
                    <Popover
                        id={id}
                        open={open}
                        anchorEl={anchorEl}
                        onClose={handleClose}
                        anchorOrigin={{
                            vertical: 'bottom',
                            horizontal: 'left',
                        }}
                    >
                        <div className="flex flex-col w-[150px] h-auto bg-[#282b34] text-[black] relative">
                            <span className="text-[#ffffff] w-[150px] h-[40px] text-center pt-[6px] cursor-pointer hover:bg-[#404450]">Settings</span>
                            <span className="text-[#ffffff] w-[150px] h-[40px] text-center pt-[6px] cursor-pointer hover:bg-[#404450]" onClick={handleCreateGroup}>Create Group</span>
                            <span className="text-[#ffffff] w-[150px] h-[40px] text-center pt-[6px] cursor-pointer hover:bg-[#404450]" onClick={handleLogOut}>Log Out</span>
                        </div>
                    </Popover>
                </div>
                <div className="flex w-[400px] h-auto  items-center">
                    <ul>
                        { groups.length > 0 && groups.map((item, index) => (
                            <>
                                <li className="w-[400px] mt-2 rounded-[8px] pl-[20px] pt-[10px] cursor-pointer h-[40px] bg-[#404450]" onClick={()=>{handleOnMessage(item,"Group")}} key={index}>{item.roomName}</li>
                            </>
                        ))}
                        {users !== null && users.length > 0 && users.map((item, index) => (
                            <>
                                <li className="w-[400px] mt-2 rounded-[8px] pl-[20px] pt-[10px] cursor-pointer h-[40px] bg-[#404450]" onClick={()=>{handleOnMessage(item,"Personal")}} key={index}>{item.name}</li>
                            </>
                        ))}
                    </ul>
                </div>
            </div>
            <Chat user={user} data={item} msgTo={item?.roomName || item?.userName} type={msgType} socket={socket} handleOnChat={handleOnChat}/>
        </>
    );
}

export default Homepage;
