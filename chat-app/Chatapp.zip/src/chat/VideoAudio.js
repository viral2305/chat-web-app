import React, {useEffect, useRef, useState} from "react";
import {useParams,useNavigate} from "react-router-dom";
import Peer from "simple-peer"
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";



const VideoAudio = ({socket,user}) => {
    const params = useParams();
    const [ me, setMe ] = useState("");
    const [ stream, setStream ] = useState();
    const [ receivingCall, setReceivingCall ] = useState(false);
    const [ caller, setCaller ] = useState("");
    const [ callerSignal, setCallerSignal ] = useState();
    const [ callAccepted, setCallAccepted ] = useState(false);
    const [ idToCall, setIdToCall ] = useState("");
    const [ callEnded, setCallEnded] = useState(false);
    const [ name, setName ] = useState(params.from);
    const userVideo = useRef();
    const connectionRef= useRef();
    const navigate = useNavigate();
    const myVideo = useRef();

    useEffect(() => {
        navigator.mediaDevices.getUserMedia({ video: true, audio: true }).then((stream) => {
            setStream(stream);
            myVideo.current.srcObject = stream
        });

        socket.on("me", (id) => {
            setMe(id)
        });

        socket.on("callUser", (data) => {
            console.log("callUser",data);
            setReceivingCall(true);
            setCaller(data.from);
            setName(data.name);
            setCallerSignal(data.signal)
        })
    }, []);
    const callUser = (id) => {
        const peer = new Peer({
            initiator: true,
            trickle: false,
            stream: stream
        });
        peer.on("signal", (data) => {
            socket.emit("callUser", {
                userToCall: id,
                signalData: data,
                from: me,
                name: name
            })
        });
        peer.on("stream", (stream) => {
            userVideo.current.srcObject = stream
        });
        socket.on("callAccepted", (signal) => {
            setCallAccepted(true);
            peer.signal(signal)
        });

        connectionRef.current = peer
    };
    const answerCall =() =>  {
        setCallAccepted(true);
        const peer = new Peer({
            initiator: false,
            trickle: false,
            stream: stream
        });
        peer.on("signal", (data) => {
            socket.emit("answerCall", { signal: data, to: caller })
        });
        peer.on("stream", (stream) => {
            userVideo.current.srcObject = stream
        });

        peer.signal(callerSignal);
        connectionRef.current = peer
    };

    const leaveCall = () => {
        setCallEnded(true);
        connectionRef.current.destroy()
        navigate(-1);
    };
    const handleGoBack = () => {
        navigate(-1);
    };
    return (
        <div className="w-[400px] h-[600px] bg-[#2d343e] p-[1rem] flex flex-col">
            <div className="flex">
                <span className="w-[40px]"><i className="far fa-arrow-left cursor-pointer" onClick={handleGoBack}/></span>
                {params.type.toUpperCase()}
            </div>
            <div className="grid justify-center content-center mt-[10px]">
                <div className="video">
                    {params.type === "video" ? callAccepted && !callEnded ?
                        <video playsinline ref={userVideo} autoPlay className="w-[300px]"/> :
                        null :
                        <div className="w-[200px] h-[200px] bg-[#282b34] text-[#ff1e56] pt-[20px] text-[100px] font-bold text-center rounded-[100px]">
                            {params.to.charAt(0).toUpperCase()}
                        </div>
                    }
                </div>
                <div className="video">
                    <video playsinline muted ref={myVideo} autoPlay className="w-[300px]"/>
                </div>
            </div>
            <div className="myId">
                <div className="mt-[20px]">
                    {callAccepted && !callEnded ? (
                        <button className="bg-[red] w-[40px] h-[40px] rounded-[20px]" onClick={leaveCall}>
                            <i className="fas fa-phone"/>
                        </button>
                    ) : "Calling...."}
                </div>
            </div>
            <div>
                {receivingCall && !callAccepted ? (
                    <div className="caller">
                        <h1 >{name} is calling...</h1>
                        <Button variant="contained" color="primary" onClick={answerCall}>
                            Answer
                        </Button>
                    </div>
                ) : null}
            </div>
        </div>
    );
};

export default VideoAudio;