import {to_Decrypt, to_Encrypt} from "../aes.js";
// import { process } from "../store/action/index";
import React, {useState, useEffect, useRef} from "react";
// import { useDispatch } from "react-redux";
import axios from "axios";
import {Link} from "react-router-dom";
import "./chat.scss";
import Peer from "simple-peer";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import {CopyToClipboard} from "react-copy-to-clipboard";
import ThreeDots from "react-loader-spinner/dist/loader/ThreeDots";

function Chat({user, data, msgTo, type, socket, handleOnChat}) {
    const [text, setText] = useState("");
    const [messages, setMessages] = useState([]);
    const [call, setCall] = useState(false);
    const [callType, setCallType] = useState('');
    const [callTo, setCallTo] = useState('');
    const [caller, setCaller] = useState("");
    const [callerSignal, setCallerSignal] = useState();
    const [receivingCall, setReceivingCall] = useState(false);
    const [idToCall, setIdToCall] = useState("")
    const [me, setMe] = useState("");
    const [stream, setStream] = useState();
    const [callAccepted, setCallAccepted] = useState(false);
    const [name, setName] = useState(user.userName);
    const [callEnded, setCallEnded] = useState(false);
    const [mic, setMic] = useState(true);
    const [video, setVideo] = useState(true);
    const userVideo = useRef();
    const connectionRef = useRef();
    const myVideo = useRef();

    // const dispatch = useDispatch();

    // const dispatchProcess = (encrypt, msg, cipher) => {
    //   dispatch(process(encrypt, msg, cipher));
    // };
    socket.on("me", (id) => {
        setMe(id)
    });
    useEffect(() => {
        if (type === "Group") {
            axios.get(`http://192.168.29.246/message/${type}`).then((res) => {
                // console.log("GROUP MESSAGE",res.data)
                res.data.map((item, index) => {
                    const ans = to_Decrypt(item.messageContent, item.msgBy);
                    if (item.msgTo === msgTo) {
                        messages.push({
                            messageContent: ans,
                            messageTime: item.messageTime,
                            msgBy: item.msgBy,
                            msgTo: item.msgTo,
                            messageType: item.messageType,
                        });
                        setMessages([...messages]);
                    }
                })
            });
        } else if (type === "Personal") {
            axios.get(`http://192.168.29.246:8000/message/${type}`).then((res) => {
                // console.log("PERSONAL MESSAGE",res.data)
                res.data.map((item, index) => {
                    const ans = to_Decrypt(item.messageContent, user.userName);
                    if ((item.msgBy === user._id && item.msgTo === data._id) || (item.msgBy === data._id && item.msgTo === user._id)) {
                        messages.push({
                            messageContent: ans,
                            messageTime: item.messageTime,
                            msgBy: item.msgBy,
                            msgTo: item.msgTo,
                            messageType: item.messageType,
                        });
                        setMessages([...messages]);
                    }
                });
            });
        }
        socket.on("message", (data) => {
            //decypt
            const ans = to_Decrypt(data.text, data.username);
            // dispatchProcess(false, ans, data.text);
            console.log("data", data);
            let temp = messages;
            temp.push({
                messageContent: ans,
                messageTime: data.messageTime,
                msgBy: data.username,
                msgTo: data.msgTo,
                messageType: type,
            });
            setMessages([...temp]);
        });

        navigator.mediaDevices.getUserMedia({video: video, audio: mic}).then((stream) => {
            setStream(stream);
            myVideo.current.srcObject = stream
        });
        socket.on("me", (id) => {
            setMe(id)
        });

        socket.on("callUser", (data) => {
            console.log("DATA",data);
            setReceivingCall(true);
            setCaller(data.from);
            setName(data.name);
            setCallerSignal(data.signal);
            setCall(true);
            setCallTo(data.to);
            setCallType(data.type);
        });
    }, [data]);


    const sendData = () => {
        let date = new Date();
        if (text !== "") {
            //encrypt here
            const ans = to_Encrypt(text);
            socket.emit("chat", {ans, userId: user._id, msgTo: data._id, date, type});
            setText("");
        }
    };
    const messagesEndRef = useRef(null);

    const scrollToBottom = () => {
        messagesEndRef.current.scrollIntoView({behavior: "smooth"});
    };

    // useEffect(scrollToBottom, [messages]);
    const handleVideoCall = (id, type) => {
        setCall(true);
        setCallType(type);
        const peer = new Peer({
            initiator: true,
            trickle: false,
            stream: stream
        });
        peer.on("signal", (data) => {
            socket.emit("callUser", {
                userToCall: id,
                signalData: data,
                from: me,
                name: name,
                to: msgTo,
                type: type,
            })
        });
        peer.on("stream", (stream) => {
            userVideo.current.srcObject = stream
        });
        socket.on("callAccepted", (signal) => {
            setCallAccepted(true);
            peer.signal(signal)
        });

        connectionRef.current = peer;
    };
    const answerCall = () => {
        setCallAccepted(true);
        const peer = new Peer({
            initiator: false,
            trickle: false,
            stream: stream
        });
        peer.on("signal", (data) => {
            socket.emit("answerCall", {signal: data, to: caller})
        });
        peer.on("stream", (stream) => {
            userVideo.current.srcObject = stream
        });

        peer.signal(callerSignal);
        connectionRef.current = peer
    };
    const leaveCall = () => {
        setCallEnded(true);
        setCall(false);
        connectionRef.current.destroy();
    };
    return (
        <div className="chat">
            {msgTo ? <>
                    <div className="flex">
                        <span className="w-[40px]" onClick={handleOnChat}><i className="far fa-arrow-left"/></span>
                        <Link to={`/groupSettings/${msgTo}`} className="cursor-pointer">
                            {msgTo}
                        </Link>
                        <div className="flex flex-row w-[40px] ml-[20px] mt-[4px]">
                            <i className="fas fa-phone-alt cursor-pointer" onClick={() => {
                                handleVideoCall(idToCall, "audio")
                            }}/>
                            <i className="fas fa-video ml-[20px] cursor-pointer"
                               onClick={() => handleVideoCall(idToCall, "video")}/>
                        </div>
                    </div>
                    <div>
                        <TextField
                            id="filled-basic"
                            label="Name"
                            variant="filled"
                            value={me}
                            onChange={(e) => setMe(e.target.value)}
                            style={{marginBottom: "20px"}}
                        />
                        <CopyToClipboard text={me} style={{marginBottom: "2rem"}}>
                            <Button variant="contained" color="primary">
                                Copy ID
                            </Button>
                        </CopyToClipboard>
                        <TextField
                            id="filled-basic"
                            label="ID to call"
                            variant="filled"
                            value={idToCall}
                            onChange={(e) => setIdToCall(e.target.value)}
                        />
                    </div>
                    {!call ? <div className="chat-message">
                            {messages.map((msg, index) => {
                                if (msg.msgBy === user._id || msg.from === user.userName) {
                                    return (
                                        <div className="message mess-right" key={index}>
                                            <p>{msg.messageContent}</p>
                                            <span>{type === "Group" ? msg.msgBy : ""}{new Date(msg.messageTime).getHours()}:{new Date(msg.messageTime).getMinutes()}{new Date(msg.messageTime).getHours() >= 12 ? "PM" : "AM"}</span>
                                        </div>
                                    );
                                } else {
                                    return (
                                        <div className="message" key={index}>
                                            <p>{msg.messageContent} </p>
                                            <span>{type === "Group" ? msg.msgBy : ""}{new Date(msg.messageTime).getHours()}:{new Date(msg.messageTime).getMinutes()}{new Date(msg.messageTime).getHours() >= 12 ? "PM" : "AM"}</span>
                                        </div>
                                    );
                                }
                            })}
                            <div ref={messagesEndRef}/>
                        </div> :
                        <div className="grid justify-center content-center mt-[10px]">
                            <div className="video">
                                {callType === "video" ? callAccepted && !callEnded ?
                                    <video playsinline ref={userVideo} autoPlay className="w-[300px]"/> :
                                    (receivingCall && !callAccepted && callTo === user.userName && name === msgTo) ?
                                        <div className="caller">
                                            <h1>{name} is calling<ThreeDots color="#ffff" height={50} width={50}/></h1>
                                        </div> : <>Calling<ThreeDots color="#ffff" height={50} width={50}/></> :
                                    <div
                                        className="w-[200px] h-[200px] bg-[#282b34] text-[#ff1e56] pt-[20px] text-[100px] font-bold text-center rounded-[100px]">
                                        {msgTo.charAt(0).toUpperCase()}
                                    </div>
                                }
                            </div>
                            <div className="video">
                                {callType === "video" ? callAccepted && !callEnded ?
                                    <video playsinline muted ref={myVideo} autoPlay className="w-[300px]"/> :
                                    null :
                                    <div
                                        className="w-[200px] h-[200px] bg-[#282b34] text-[#ff1e56] pt-[20px] text-[100px] font-bold text-center rounded-[100px]">
                                        {user.userName.charAt(0).toUpperCase()}
                                    </div>
                                }
                            </div>
                        </div>
                    }
                    {!call ?
                        <div className="send">
                            <input
                                placeholder="enter your message"
                                value={text}
                                onChange={(e) => setText(e.target.value)}
                                onKeyPress={(e) => {
                                    if (e.key === "Enter") {
                                        sendData();
                                    }
                                }}
                            />
                            <button onClick={sendData}>Send</button>
                        </div> :
                        <div>
                            {receivingCall && !callAccepted && callTo === user.userName && name === msgTo ? (
                                    <div className="caller">
                                        <button className="bg-[green] animate-bounce w-[40px] h-[40px] rounded-[20px]" onClick={answerCall}>
                                            <i className="fas fa-phone-alt"/>
                                        </button>
                                    </div>
                                ) :
                                <div className="flex justify-between">
                                    <button className="bg-[#3F51B5] w-[40px] h-[40px] rounded-[20px] mr-[20px]" onClick={() => setMic(!mic)}>
                                        {mic ? <i className="fas fa-microphone"/>:<i class="fas fa-microphone-slash"/>}
                                    </button>
                                    <button className="bg-[red] w-[40px] h-[40px] rounded-[20px]" onClick={leaveCall}>
                                        <i className="fas fa-phone"/>
                                    </button>
                                    <button className="bg-[#3F51B5] w-[40px] h-[40px] rounded-[20px] ml-[20px]" onClick={() => setVideo(!video)}>
                                        {video ? <i className="fas fa-video"/> : <i class="fas fa-video-slash"/>}
                                    </button>
                                </div>}
                        </div>
                    }</> :
                <div className="items-center">

                </div>
            }
        </div>
    );
}

export default Chat;
