import React, {useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import axios from "axios";
import {Redirect} from "react-router";

const Login = () => {
    let navigate = useNavigate();
    const [user, setUser] = useState({email: "", password: ""});
    const [remember, setRemember] = useState(false);

    const handleOnChange = (event) => {
        let {name, value} = event.target;
        setUser({...user, [name]: value});
    };
    const handleOnSubmit =async () => {
        await axios.post("http://192.168.29.246:8000/login",user).then((res) => {
            if(res.data.success){
                localStorage.setItem("user",JSON.stringify(res.data.data));
                window.location.href = "/";
            }
        });
        // if (username !== "" && roomname !== "") {
        //     socket.emit("joinRoom", { username, roomname });
        // } else {
        //     alert("username and roomname are must !");
        //     window.location.reload();
        // }
    };
    const {name, userName, email, password} = user;
    return (
        <div className="flex w-[500px] h-[500px] bg-[#2d343e] justify-evenly items-center rounded-[5px] flex-col p-8">
            <h1>Welcome to ChatApp</h1>
            <input
                placeholder="Enter your email"
                name={"email"}
                value={email}
                onChange={(e) => handleOnChange(e)}
                className="h-[50px] w-[80%] bg-[#404450] rounded-[5px] border-none pl-[10px]"
            />
            <input
                placeholder="Enter your password again"
                type="password"
                name={"password"}
                value={password}
                onChange={(e) => handleOnChange(e)}
                className="h-[50px] w-[80%] bg-[#404450] rounded-[5px] border-none pl-[10px]"
            />
            <button
                className="w-[100px] pt-[0.5rem] pr-[1rem] pb-[0.5rem] pl-[1rem] border-none bg-[#ffac41] rounded-[5px] text-[black] cursor-pointer"
                onClick={handleOnSubmit}>Submit
            </button>
            <div className="flex flex-col items-start">
                <Link to="/login" className="text-[blue]">Forgot Password?</Link>
                If you don't have an account?<Link to="/login" className="text-[blue]">Sign In</Link>
            </div>
        </div>
    );
}
export default Login;
