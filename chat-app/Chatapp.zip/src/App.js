import Chat from "./chat/chat";
import Process from "./process/process";
import Home from "./home/home";
import { BrowserRouter as Router,Routes, Route } from "react-router-dom";
import "./App.scss";
import React from "react";
import io from "socket.io-client";
import Login from "./Login/Login";
import Register from "./Register/Register";
import GroupSetting from "./Settings/GroupSetting";
import CreateGroup from "./Settings/CreateGroup";
import VideoAudio from "./chat/VideoAudio";

const socket = io.connect('192.168.29.246:3000/');
function App(props) {
    const user  = JSON.parse(localStorage.getItem("user"));
  return (
      <Router>
        <div className="App">
          <Routes>
              <Route path="/login" exact element={ <Login />}/>
              <Route path="/register" exact element={ <Register />}/>
              <Route path="/" exact element={ <Home socket={socket} user={user}/>}/>
              <Route path="/createGroup" element={<CreateGroup/>} exact/>
              <Route path="/groupSettings/:id" element={<GroupSetting />} exact/>
              <Route path="/call/:type/:from/:to" element={<VideoAudio socket={socket}/>} exact/>
          </Routes>
        </div>
      </Router>
  );
}

export default App;
