import React, {useState} from "react";
import {Link} from "react-router-dom";
import axios from "axios";

const Register = () => {
    const [user, setUser] = useState({name: "", userName: "", email: "", password: ""});
    const [remember, setRemember] = useState(false);

    const handleOnChange = (event) => {
        let {name, value} = event.target;
        setUser({...user, [name]: value});
    };
    const handleOnSubmit =async () => {
       await axios.post("http://localhost:8000/register",user);
        // if (username !== "" && roomname !== "") {
        //     socket.emit("joinRoom", { username, roomname });
        // } else {
        //     alert("username and roomname are must !");
        //     window.location.reload();
        // }
    };
    const {name, userName, email, password} = user;
    return (
        <div className="flex w-[500px] h-[500px] bg-[#2d343e] justify-evenly items-center rounded-[5px] flex-col p-8">
            <h1>Welcome to ChatApp</h1>
            <input
                placeholder="Enter your name"
                type="text"
                name="name"
                value={name}
                onChange={(e) => handleOnChange(e)}
                className="h-[50px] w-[80%] bg-[#404450] rounded-[5px] border-none pl-[10px]"
            />
            <input
                placeholder="Enter your username"
                type="text"
                value={userName}
                name={"userName"}
                onChange={(e) => handleOnChange(e)}
                className="h-[50px] w-[80%] bg-[#404450] rounded-[5px] border-none pl-[10px]"
            />
            <input
                placeholder="Enter your email"
                name={"email"}
                value={email}
                onChange={(e) => handleOnChange(e)}
                className="h-[50px] w-[80%] bg-[#404450] rounded-[5px] border-none pl-[10px]"
            />
            <input
                placeholder="Enter your password"
                type="password"
                name={"password"}
                value={password}
                onChange={(e) => handleOnChange(e)}
                className="h-[50px] w-[80%] bg-[#404450] rounded-[5px] border-none pl-[10px]"
            />
            <input
                placeholder="Enter your password again"
                type="password"
                name={"password"}
                value={password}
                onChange={(e) => handleOnChange(e)}
                className="h-[50px] w-[80%] bg-[#404450] rounded-[5px] border-none pl-[10px]"
            />
            <button
                className="w-[100px] pt-[0.5rem] pr-[1rem] pb-[0.5rem] pl-[1rem] border-none bg-[#ffac41] rounded-[5px] text-[black] cursor-pointer"
                onClick={handleOnSubmit}>Submit
            </button>
            <div className="flex flex-col items-start">
                already registerd ?<Link to="/login" className="text-[blue]">Log In</Link>
            </div>
        </div>
    );
}
export default Register;
