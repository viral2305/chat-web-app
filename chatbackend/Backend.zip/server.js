const express = require("express");
const app = express();
const socket = require("socket.io");
const color = require("colors");
const cors = require("cors");
const mongoose  = require("mongoose");
const Message = require("./Models/Messages");
const Room = require("./Models/Rooms");
const User = require("./Models/User");
const uri = "mongodb://localhost:27017/ChatApp";
const { get_Current_User, user_Disconnect, join_User } = require("./dummyuser");

app.use(cors());
app.use(express.json());

app.use(express());
app.get("/message/:type",async (req,res) => {
  const d = await Message.find({messageType:req.params.type});
  res.send(d);
});

app.get("/users",async (req,res) => {
  const users = await User.find();
  res.send(users);
});

app.post("/login",async (req,res) => {
  const {email, password} =req.body;
  const p_user = await User.findOne({email: email,password:password});
  if(p_user){
    res.send({success:true,data:p_user});
  }
  else{
    res.send({error:"user not found"});
  }
});

app.post("/register",async (req,res) => {
  const {name, userName, email, password} =req.body;
  const p_user = await User.findOne({email: email});
  if(p_user && p_user.email === email){
    res.send("User Already Exists");
  }
  else {
    const user = new User(req.body);
    user.save(function (error, document) {
      if (error) console.error(error)
      console.log(document)
    });
    res.send("successfully Register");
  }
});

app.post("/createGroup",async (req,res) => {
  const {name,members} =req.body;
  const room = new Room({
    roomName:name,
    members:members
  });
  room.save(function (error, document) {
    if (error) console.error(error);
    console.log(document)
  });
  res.send("Group Successfully Created");
});

app.get("/groups/:user",async (req,res) => {
  let data = await Room.find();
  let group = [];
  data.map((item,i) => {
    if(item.members.includes(req.params.user)){
      group.push(item);
    }
  });
  res.send(group);
});
app.get("/group/:name",async (req,res) => {
  console.log("req.params",req.params);
  let data = await Room.findOne({roomName:req.params.name});
  res.send(data);
});

const port = 8000;
mongoose.connect(uri).then(()=>{
  console.log("Mongodb Connented");
}).catch(()=>{
  console.log("Mongodb Error");
});
var server = app.listen(
  port,
  console.log(
    `Server is running on the port no: ${(port)} `
      .green
  )
);

const io = socket(server);

//initializing the socket io connection 
io.on("connection", (socket) => {
  //for a new user joining the room
    socket.emit("me", socket.id);

    socket.on("disconnect", () => {
      socket.broadcast.emit("callEnded")
    });

    socket.on("callUser", (data) => {
      console.log("callUser",data);
      io.to(data.userToCall).emit("callUser", { signal: data.signalData, from: data.from, name: data.name,to:data.to,type:data.type })
    });

    socket.on("answerCall", (data) => {
      io.to(data.to).emit("callAccepted", data.signal)
    });
  socket.on("joinRoom", ({ username, roomname }) => {
    //* create user
    const p_user = join_User(socket.id, username, roomname);

    console.log(socket.id, "=id");
    socket.join(p_user.room);
    //display a welcome message to the user who have joined a room
    socket.emit("message", {
      userId: p_user.id,
      username: p_user.username,
      text: `Welcome ${p_user.username}`,
    });

    //displays a joined room message to all other room users except that particular user
    socket.broadcast.to(p_user.room).emit("message", {
      userId: p_user.id,
      username: p_user.username,
      text: `${p_user.username} has joined the chat`,
    });
  });

  //user sending message
  socket.on("chat",async ({ans,userId,msgTo,date,type}) => {
    //gets the room user and the message sent
    get_Current_User(socket.id);
    const p_user = await User.findOne({_id: userId});
    console.log("p_user", p_user);
    const message = new Message({
      messageContent: ans,
      messageTime: date,
      msgBy: userId,
      msgTo: msgTo,
      messageType: type,
    });
    message.save(function (error, document) {
      if (error) console.error(error);
      console.log('document',document)
    });
    socket.broadcast.emit("message", {
      userId: p_user.id,
      username: p_user.userName,
      messageTime: date,
      msgTo: msgTo,
      text: ans,
    });
  });
  //   socket.on("PersonalChat",async ({msg,from,to,msgId,date}) => {
  //     const p_user = await User.findOne({userName: from});
  //     const personalMsg = new PersonalMessage ({
  //       messageContent: msg,
  //       messageTime: date,
  //       from: p_user.userName,
  //       to:to,
  //       msgId: msgId,
  //     });
  //     personalMsg.save(function (error, document) {
  //       if (error) console.error(error)
  //       console.log(document)
  //     });
  //   io.to(msgTo).emit("message", {
  //     userId: p_user.id,
  //     username: p_user.userName,
  //     text: ans,
  //   });
  // });

  //when the user exits the room
  socket.on("disconnect", () => {
    //the user is deleted from array of users and a left room message displayed
    const p_user = user_Disconnect(socket.id);

    if (p_user) {
      io.to(p_user.room).emit("message", {
        userId: p_user.id,
        username: p_user.username,
        text: `${p_user.username} has left the chat`,
      });
    }
  });
});